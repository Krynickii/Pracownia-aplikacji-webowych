import Heading from "../../components/Heading";

function About() {
  return (
    <div>
      <Heading title='About us' level={1} />
    </div>
  )
}

export default About
